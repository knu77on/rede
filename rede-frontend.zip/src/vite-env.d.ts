/// <reference types="vite/client" />
