// ============================================================
// REDE - Speech-to-Text Service (Gemini Flash 2)
// Legacy module — re-exports from gemini.ts
// ============================================================

export { transcribe } from "./gemini";
